package android.exampl.earth;

import org.xml.sax.DTDHandler;

public class earthhqq {
    private String mmag;
    private String mlocation;
    private long mTimeInMilliseconds;


    public earthhqq(String magnitude, String location, long timeInMilliseconds) {
        mmag = magnitude;
        mlocation = location;
        mTimeInMilliseconds = timeInMilliseconds;
    }
    public String getMmag (){ return mmag;}
    public String getMlocation (){ return mlocation;}

    public long getTimeInMilliseconds() {
        return mTimeInMilliseconds;
    }
}
