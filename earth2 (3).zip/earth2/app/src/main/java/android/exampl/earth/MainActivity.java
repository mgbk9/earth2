package android.exampl.earth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<earthhqq> earth = queryutils.extractEarthquakes();

        ListView listView = (ListView) findViewById(R.id.list);
        earthAdapter adapter = new earthAdapter(this, earth);
        listView.setAdapter(adapter);
    }
}